<form action="verificacion.php">
	<img src="../captcha.php" /><br/>
	<input type="text" size="16" name="captcha" />
	<br/><br/>
	<input type="submit" />
</form>